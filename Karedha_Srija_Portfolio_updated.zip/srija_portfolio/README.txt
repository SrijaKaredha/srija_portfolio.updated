KARE DHA SRIJA PORTFOLIO

1. Keep index.html, style.css, script.js and the assets folder together.
2. Double-click index.html to preview the portfolio in your browser.
3. To publish with GitHub Pages, upload all files and folders to a GitHub repository, then enable Pages in Settings > Pages.
4. Your profile photo is in assets/srija-profile.jpeg.
5. Update the text, links, and project details in index.html whenever needed.
